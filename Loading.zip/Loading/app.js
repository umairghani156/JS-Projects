const btn = document.querySelector('button');
const loading = document.querySelector('.loading')
btn.addEventListener('click', function(){
    loading.style.display = "flex";
    this.style.display= 'none'
})